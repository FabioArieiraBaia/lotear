<?php
/**
 * Script de Carga de Lotes para o Loteamento 10 (PDF)
 * Pode ser executado acessando directly: /api/carga_lotes.php
 */
require_once __DIR__ . '/db.php';

try {
    $db = getDatabase();
    $loteamentoId = 10;
    
    // Verificar se o loteamento existe
    $stmt = $db->prepare("SELECT id FROM loteamentos WHERE id = ?");
    $stmt->execute([$loteamentoId]);
    if (!$stmt->fetch()) {
        die("Erro: Loteamento 10 não encontrado no banco de dados.");
    }

    $quadras = [
        'A' => [
            1 => '735,53', 2 => '356,87', 3 => '320,48', 4 => '285,00',
            5 => '415,89', 6 => '387,32', 7 => '300,96', 8 => '285,74',
            9 => '308,99', 10 => '517,08', 11 => '364,27', 12 => '690,86'
        ],
        'B' => [
            1 => '425,16', 2 => '403,26', 3 => '518,88', 4 => '562,64',
            5 => '577,29', 6 => '594,95', 7 => '632,92', 8 => '562,03',
            9 => '778,91', 10 => '641,48', 11 => '642,93', 12 => '547,68',
            13 => '533,70', 14 => '536,72', 15 => '555,53', 16 => '992,72'
        ],
        'C' => [
            1 => '142,24', 2 => '713,54', 3 => '408,46', 4 => '450,17',
            5 => '625,31', 6 => '956,58', 7 => '811,21', 8 => '476,45',
            9 => '478,74', 10 => '263,01', 11 => '514,49', 12 => '555,72',
            13 => '389,25', 14 => '450,99', 15 => '414,60', 16 => '409,42',
            17 => '411,65', 18 => '411,72', 19 => '395,14', 20 => '336,67'
        ],
        'D' => [
            1 => '707,99', 2 => '327,85', 3 => '369,23', 4 => '424,44',
            5 => '482,69', 6 => '532,24', 7 => '398,53', 8 => '460,41',
            9 => '469,44', 10 => '495,31', 11 => '523,92', 12 => '659,81',
            13 => '610,06', 14 => '996,96', 15 => '1.331,29', 16 => '584,95',
            17 => '575,12', 18 => '576,39', 19 => '585,21', 20 => '578,86',
            21 => '1.133,60', 22 => '560,91', 23 => '500,25', 24 => '901,86'
        ]
    ];
    
    // Coordenadas iniciais para os marcadores na tela
    $y_start = [
        'A' => 100,
        'B' => 160,
        'C' => 220,
        'D' => 280
    ];
    
    $inserted = 0;
    $updated = 0;
    
    foreach ($quadras as $q_name => $lotes) {
        $y = $y_start[$q_name];
        foreach ($lotes as $num => $area) {
            $name = sprintf("Q %s - L %02d", $q_name, $num);
            
            // Verificar se o lote já existe no banco
            $stmt = $db->prepare("SELECT id FROM lotes WHERE loteamentoId = ? AND name = ?");
            $stmt->execute([$loteamentoId, $name]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Atualizar área, preservar o polígono existente
                $stmtUpdate = $db->prepare("UPDATE lotes SET area = ? WHERE id = ?");
                $stmtUpdate->execute([$area, $existing['id']]);
                $updated++;
            } else {
                // Criar coordenadas de polígono padrão
                $x = 50 + ($num - 1) * 35;
                $polygon = [
                    [$y, $x],
                    [$y, $x + 25],
                    [$y + 25, $x + 25],
                    [$y + 25, $x]
                ];
                $polygon_str = json_encode($polygon);
                
                $stmtInsert = $db->prepare("INSERT INTO lotes (loteamentoId, name, polygon, area, status) VALUES (?, ?, ?, ?, ?)");
                $stmtInsert->execute([$loteamentoId, $name, $polygon_str, $area, 'Disponível']);
                $inserted++;
            }
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Carga de lotes concluída com sucesso.',
        'inseridos' => $inserted,
        'atualizados' => $updated,
        'total' => $inserted + $updated
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
